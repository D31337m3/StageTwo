import microcontroller
import storage
import usb_cdc
import usb_hid
import supervisor
import time
import board
import rtc
import displayio
import adafruit_ntp
import adafruit_sdcard
import adafruit_imageload
import socketpool
import os
import wifi
import busio
import digitalio
import gc
import terminalio
from adafruit_display_text import label

# NVM flag positions
RECOVERY_FLAG_ADDR = 0
DEVELOPER_MODE_FLAG_ADDR = 1
FLASH_WRITE_FLAG_ADDR = 2
RELOAD_COUNTER_ADDR = 3
RESET_TYPE_ADDR = 4
BOOT_LOOP_THRESHOLD_ADDR = 5
LAST_SUCCESSFUL_BOOT_ADDR = 6
USB_HOST_ADDR = 7
FIRST_BOOT_SETUP_FLAG_ADDR = 8

# Reset type constants
RESET_POWER_ON = 1
RESET_BROWNOUT = 2
RESET_SOFTWARE = 3
RESET_WATCHDOG = 4
RESET_UNKNOWN = 5

# SD Card Constants
SCK = board.SD_SCK
MOSI = board.SD_MOSI
MISO = board.SD_MISO
SPI = busio.SPI(SCK, MOSI, MISO)
CS = digitalio.DigitalInOut(board.SD_CS)

DEFAULT_BOOT_LOOP_THRESHOLD = 3
SUCCESSFUL_BOOT_DELAY = 5

SETTINGS_PATH = "/settings.toml"
DEFAULT_BOOT_FILE = "app_loader.py"
DEFAULT_TIMEOUT = 3

BOOT_FILES = ["app_loader.py", "main.py", "code.py", "user_app.py"]

# --- Settings helpers ---
def read_settings():
    settings = {
        "DEFAULT_BOOT_FILE": DEFAULT_BOOT_FILE,
        "BOOT_TIMEOUT": DEFAULT_TIMEOUT,
        "DEVELOPER_MODE": False,
        "FLASH_WRITE": False,
    }
    try:
        os.stat(SETTINGS_PATH)
        with open(SETTINGS_PATH, "r") as f:
            for line in f:
                if line.startswith("DEFAULT_BOOT_FILE"):
                    settings["DEFAULT_BOOT_FILE"] = line.split("=")[1].strip().replace('"', "")
                elif line.startswith("BOOT_TIMEOUT"):
                    try:
                        settings["BOOT_TIMEOUT"] = int(line.split("=")[1].strip())
                    except Exception:
                        pass
                elif line.startswith("DEVELOPER_MODE"):
                    settings["DEVELOPER_MODE"] = "True" in line or "1" in line
                elif line.startswith("FLASH_WRITE"):
                    settings["FLASH_WRITE"] = "True" in line or "1" in line
    except OSError:
        pass
    return settings

def save_settings(settings):
    lines = []
    try:
        os.stat(SETTINGS_PATH)
        with open(SETTINGS_PATH, "r") as f:
            for line in f:
                if line.startswith("DEFAULT_BOOT_FILE"):
                    continue
                elif line.startswith("BOOT_TIMEOUT"):
                    continue
                elif line.startswith("DEVELOPER_MODE"):
                    continue
                elif line.startswith("FLASH_WRITE"):
                    continue
                lines.append(line)
    except OSError:
        pass
    lines.append(f'DEFAULT_BOOT_FILE = "{settings["DEFAULT_BOOT_FILE"]}"\n')
    lines.append(f'BOOT_TIMEOUT = {settings["BOOT_TIMEOUT"]}\n')
    lines.append(f'DEVELOPER_MODE = {int(settings["DEVELOPER_MODE"])}\n')
    lines.append(f'FLASH_WRITE = {int(settings["FLASH_WRITE"])}\n')
    with open(SETTINGS_PATH, "w") as f:
        f.writelines(lines)

settings = read_settings()

# --- NVM helpers ---
def set_nvm_flag(address, value):
    microcontroller.nvm[address] = 1 if value else 0

def read_nvm_flag(address):
    try:
        return microcontroller.nvm[address] == 1
    except IndexError:
        return False

def read_nvm_byte(address):
    try:
        return microcontroller.nvm[address]
    except IndexError:
        return 0

def write_nvm_byte(address, value):
    try:
        microcontroller.nvm[address] = min(255, max(0, value))
    except IndexError:
        pass

def sync_nvm_flags_from_settings():
    dev_mode = settings["DEVELOPER_MODE"]
    flash_write = settings["FLASH_WRITE"]
    set_nvm_flag(DEVELOPER_MODE_FLAG_ADDR, dev_mode)
    set_nvm_flag(FLASH_WRITE_FLAG_ADDR, flash_write)

# --- Boot logic ---
def configure_usb_and_storage(developer_mode, flash_write_enabled):
    usb_cdc.enable(console=True, data=False)
    if developer_mode:
        print("Developer Mode")
        usb_hid.enable()
    else:
        print("User mode")
        usb_hid.disable()
    if flash_write_enabled:
        print("Flash R/W, USB drive hidden")
        storage.remount("/", readonly=False)
        storage.disable_usb_drive()
    else:
        print("Flash R/O, USB drive hidden")
        storage.remount("/", readonly=True)
        storage.disable_usb_drive()

def prepare_sdcard():
    try:
        sdcard = adafruit_sdcard.SDCard(SPI, CS)
        vfs = storage.VfsFat(sdcard)
        storage.mount(vfs, '/sd')
        os.listdir('/sd')
    except Exception as e:
        print(f"   - SDCARD Fail:{e}")
        time.sleep(3)

def set_time_if_wifi():
    wifi_ssid = os.getenv("CIRCUITPY_WIFI_SSID")
    wifi_password = os.getenv("CIRCUITPY_WIFI_PASSWORD")
    if wifi_ssid is None:
        print("First Run , WiFi credentials missing n\\  --->settings.toml")
        raise ValueError("SSID not found")
    try:
        wifi.radio.connect(wifi_ssid, wifi_password)
    except ConnectionError:
        print("WiFi-Fail - Bad Password ")
        raise
    pool = socketpool.SocketPool(wifi.radio)
    ntp = adafruit_ntp.NTP(pool, tz_offset=0, cache_seconds=3600)
    rtc.RTC().datetime = ntp.datetime

def show_splash():
    display = board.DISPLAY
    image, palette = adafruit_imageload.load(
        "stagetwo_boot.bmp", bitmap=displayio.Bitmap, palette=displayio.Palette
    )
    tile_grid = displayio.TileGrid(image, pixel_shader=palette)
    group = displayio.Group()
    group.append(tile_grid)
    board.DISPLAY.root_group = group
    time.sleep(2)
    display.root_group = None

def run_first_boot_setup():
    if not read_nvm_flag(FIRST_BOOT_SETUP_FLAG_ADDR):
        return
    print("=== Welcome to First Boot Setup ===")
    set_nvm_flag(FLASH_WRITE_FLAG_ADDR, True)
    display = board.DISPLAY
    try:
        image, palette = adafruit_imageload.load(
            "welcome.bmp", bitmap=displayio.Bitmap, palette=displayio.Palette
        )
        tile_grid = displayio.TileGrid(image, pixel_shader=palette)
        group = displayio.Group()
        group.append(tile_grid)
        display.root_group = group
        time.sleep(2)
        display.root_group = None
    except Exception:
        print("No welcome image, using text mode.")
    print("Press the button to continue setup...")
    button = digitalio.DigitalInOut(board.BUTTON)
    button.switch_to_input(pull=digitalio.Pull.UP)
    while button.value:
        time.sleep(0.1)
    required_dirs = ["apps", "user", "config", "data", "logs"]
    for d in required_dirs:
        dir_path = f"/sd/{d}"
        try:
            os.mkdir(dir_path)
            print(f"Created: {dir_path}")
        except OSError:
            print(f"Exists: {dir_path}")
    print("Directories ready. Press button to continue to WiFi setup.")
    while button.value:
        time.sleep(0.1)
    try:
        exec(open("wifi_config.py").read())
    except Exception as e:
        print(f"WiFi config failed: {e}")
    print("Press button to continue to timezone setup.")
    while button.value:
        time.sleep(0.1)
    try:
        exec(open("timezone_setup.py").read())
    except Exception as e:
        print(f"Timezone setup failed: {e}")
    print("Setup complete! Clearing setup flag and rebooting...")
    set_nvm_flag(FIRST_BOOT_SETUP_FLAG_ADDR, False)
    time.sleep(2)
    microcontroller.reset()

def very_early_boot_ops():
    supervisor.runtime.autoreload = False
    gc.enable()
    try:
        import usb_midi
        usb_midi.disable()
    except Exception:
        print("   -USB_MIDI mode FAILED TO DISABLE")
    try:
        if read_nvm_flag(USB_HOST_ADDR) == 1:
            try:
                import usb_host
                usb_host.enable()
                print("   -USB_HOST mode Enabled by NVM Flag")
            except Exception:
                print("   -USB-HOST mode Enabled bt NVM Flag BUT FAILED")
        else:
            try:
                import usb_host
                usb_host.disable()
            except Exception:
                pass
    except Exception:
        print("    *  SOME USB configuration failed.")
    try:
        set_time_if_wifi()
    except Exception as e:
        print(f"Skipping time sync: {e}")
    try:
        prepare_sdcard()
    except Exception as e:
        print(f"Skipping SD card: {e}")
    try:
        sync_nvm_flags_from_settings()
    except Exception as e:
        print(f"Skipping NVM sync: {e}")
    try:
        run_first_boot_setup()
    except Exception as e:
        print(f"Skipping first boot setup: {e}")

# --- Boot menu logic ---
MENU_ITEMS = [
    ("Boot Normal", "boot"),
    ("Recovery Mode", "recovery.py"),
    ("Boot Settings", "settings"),
    ("Factory Reset", "factory.py"),
    ("Backup System Files", "backup"),
]

display = board.DISPLAY
group = displayio.Group()
display.root_group = group

button = digitalio.DigitalInOut(board.BUTTON)
button.direction = digitalio.Direction.INPUT
button.pull = digitalio.Pull.UP

selected = 0

def draw_menu(selected_index):
    if len(group) > 0:
        group.pop()
    menu_group = displayio.Group()
    title = label.Label(
        terminalio.FONT, text="Boot Menu", color=0x00FFFF, x=10, y=8, scale=2
    )
    menu_group.append(title)
    for i, (item, _) in enumerate(MENU_ITEMS):
        y = 30 + i * 24
        if i == selected_index:
            highlight_bitmap = displayio.Bitmap(120, 20, 1)
            highlight_palette = displayio.Palette(1)
            highlight_palette[0] = 0x003366
            highlight_tile = displayio.TileGrid(
                highlight_bitmap, pixel_shader=highlight_palette, x=6, y=y - 12
            )
            menu_group.append(highlight_tile)
            color = 0xFFFF00
        else:
            color = 0xFFFFFF
        text = label.Label(
            terminalio.FONT, text=item, color=color, x=10, y=y
        )
        menu_group.append(text)
    group.append(menu_group)

def settings_menu():
    idx = 0
    options = [
        f"Boot File: {settings['DEFAULT_BOOT_FILE']}",
        f"Timeout: {settings['BOOT_TIMEOUT']}s",
        f"Developer Mode: {'ON' if settings['DEVELOPER_MODE'] else 'OFF'}",
        f"Flash Write: {'ON' if settings['FLASH_WRITE'] else 'OFF'}",
        "Back"
    ]
    while True:
        if len(group) > 0:
            group.pop()
        menu_group = displayio.Group()
        title = label.Label(
            terminalio.FONT, text="Boot Settings", color=0x00FFFF, x=10, y=8, scale=2
        )
        menu_group.append(title)
        for i, item in enumerate(options):
            y = 30 + i * 24
            if i == idx:
                highlight_bitmap = displayio.Bitmap(120, 20, 1)
                highlight_palette = displayio.Palette(1)
                highlight_palette[0] = 0x003366
                highlight_tile = displayio.TileGrid(
                    highlight_bitmap, pixel_shader=highlight_palette, x=6, y=y - 12
                )
                menu_group.append(highlight_tile)
                color = 0xFFFF00
            else:
                color = 0xFFFFFF
            text = label.Label(
                terminalio.FONT, text=item, color=color, x=10, y=y
            )
            menu_group.append(text)
        group.append(menu_group)

        last_button = button.value
        while True:
            if not button.value and last_button:
                press_time = time.monotonic()
                while not button.value:
                    if time.monotonic() - press_time > 1.0:
                        # Long press: select
                        if idx == 0:
                            bf_idx = BOOT_FILES.index(settings["DEFAULT_BOOT_FILE"]) if settings["DEFAULT_BOOT_FILE"] in BOOT_FILES else 0
                            bf_idx = (bf_idx + 1) % len(BOOT_FILES)
                            settings["DEFAULT_BOOT_FILE"] = BOOT_FILES[bf_idx]
                            options[0] = f"Boot File: {settings['DEFAULT_BOOT_FILE']}"
                        elif idx == 1:
                            settings["BOOT_TIMEOUT"] = (settings["BOOT_TIMEOUT"] + 1) % 11 or 1
                            options[1] = f"Timeout: {settings['BOOT_TIMEOUT']}s"
                        elif idx == 2:
                            settings["DEVELOPER_MODE"] = not settings["DEVELOPER_MODE"]
                            options[2] = f"Developer Mode: {'ON' if settings['DEVELOPER_MODE'] else 'OFF'}"
                        elif idx == 3:
                            settings["FLASH_WRITE"] = not settings["FLASH_WRITE"]
                            options[3] = f"Flash Write: {'ON' if settings['FLASH_WRITE'] else 'OFF'}"
                        elif idx == 4:
                            save_settings(settings)
                            return
                        save_settings(settings)
                        break
                    time.sleep(0.01)
                else:
                    idx = (idx + 1) % len(options)
                    break
            last_button = button.value
            time.sleep(0.02)

def run_action(index):
    name, action = MENU_ITEMS[index]
    if action == "boot":
        supervisor.set_next_code_file(settings["DEFAULT_BOOT_FILE"])
        supervisor.reload()
    elif action == "settings":
        settings_menu()
        draw_menu(selected)
    elif action == "factory.py":
        FIRST_BOOT_SETUP_FLAG_ADDR = 8
        microcontroller.nvm[FIRST_BOOT_SETUP_FLAG_ADDR] = 1
        supervisor.set_next_code_file(action)
        supervisor.reload()
    elif action == "backup":
        try:
            import recovery
            rec = recovery.RecoverySystem()
            result = rec.backup_system_files()
            msg = "Backup complete!" if result else "Backup failed!"
        except Exception as e:
            msg = f"Backup error: {e}"
        if len(group) > 0:
            group.pop()
        msg_group = displayio.Group()
        msg_label = label.Label(terminalio.FONT, text=msg, color=0x00FF00 if "complete" in msg else 0xFF0000, x=10, y=60, scale=2)
        msg_group.append(msg_label)
        group.append(msg_group)
        time.sleep(2)
        draw_menu(selected)
    else:
        supervisor.set_next_code_file(action)
        supervisor.reload()

def menu_loop():
    global selected
    draw_menu(selected)
    last_button = button.value
    start_time = time.monotonic()
    timeout = settings["BOOT_TIMEOUT"]
    button_press_time = None
    prev_selected = selected
    long_press_handled = False

    while True:
        input_received = False
        if supervisor.runtime.serial_bytes_available:
            cmd = input().strip().lower()
            input_received = True
            if cmd in ["up", "u"]:
                selected = (selected - 1) % len(MENU_ITEMS)
            elif cmd in ["down", "d"]:
                selected = (selected + 1) % len(MENU_ITEMS)
            elif cmd in ["select", "s", "enter"]:
                run_action(selected)
            elif cmd.isdigit() and 0 <= int(cmd) < len(MENU_ITEMS):
                selected = int(cmd)
            else:
                print("Commands: up/down/select or 0-3")
        if not button.value and last_button:
            button_press_time = time.monotonic()
            long_press_handled = False
        elif not button.value and button_press_time is not None:
            if not long_press_handled and (time.monotonic() - button_press_time > 1.0):
                run_action(selected)
                long_press_handled = True
        elif button.value and not last_button:
            if button_press_time is not None and not long_press_handled:
                selected = (selected + 1) % len(MENU_ITEMS)
                input_received = True
            button_press_time = None
            long_press_handled = False
        last_button = button.value

        if selected != prev_selected:
            draw_menu(selected)
            prev_selected = selected

        if input_received:
            start_time = time.monotonic()
        if time.monotonic() - start_time > timeout:
            print(f"Timeout reached. Booting default: {MENU_ITEMS[selected][0]}")
            run_action(selected)

        time.sleep(0.02)

# --- Main execution flow ---
def main():
    reset_type = read_nvm_byte(RESET_TYPE_ADDR)
    reload_count = read_nvm_byte(RELOAD_COUNTER_ADDR)
    write_nvm_byte(RELOAD_COUNTER_ADDR, (reload_count + 1) % 256)
    if reload_count >= DEFAULT_BOOT_LOOP_THRESHOLD:
        set_nvm_flag(RECOVERY_FLAG_ADDR, True)
        print("!!! BOOT LOOP DETECTED !!!")
        print("Recovery mode enabled")
        print("Waiting 5sec. before recovery...")
        time.sleep(5)
    if read_nvm_flag(RECOVERY_FLAG_ADDR):
        print("Recovery flag detected - entering recovery mode")
        write_nvm_byte(RELOAD_COUNTER_ADDR, 0)
        try:
            storage.remount("/", readonly=False)
        except Exception as e:
            print(f"Failed to enable flash write access: {e}")
        try:
            import recovery
            recovery.main()
        except ImportError:
            print("ERROR: recovery.py not found!")
            try:
                exec(open("recovery.py").read())
            except OSError:
                print("Creating emergency recovery mode...")
        except Exception as e:
            print(f"Recovery system error: {e}")
        #return  # <--- Prevents continuing to menu if in recovery
    show_splash()
    # Clear splash, then re-assign display group for menu
    display.root_group = None
    time.sleep(1)
    display.root_group = group
    
    try:
        very_early_boot_ops()
    except Exception as e:
        print(f"Boot ops error: {e}")
    developer_mode = read_nvm_flag(DEVELOPER_MODE_FLAG_ADDR)
    flash_write_enabled = read_nvm_flag(FLASH_WRITE_FLAG_ADDR)
    configure_usb_and_storage(developer_mode, flash_write_enabled)
    print(f"Dev mode: {developer_mode}, R/W: {flash_write_enabled}")
    print(f"Boot OK {SUCCESSFUL_BOOT_DELAY} seconds")
    print("Boot Menu: Use button or console (up/down/select/0-3)")
    menu_loop()

if __name__ == "__main__":
    main()