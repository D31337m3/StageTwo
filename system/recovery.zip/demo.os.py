"""
StageTwo OS Demo
Complete demonstration of the operating system
"""

import time
import gc

def demo_stagetwo_os():
    """Demonstrate the StageTwo OS"""
    
    print("🚀 StageTwo OS - Demo Starting...")
    print("=" * 50)
    
    try:
        # Import and start the OS
        from stagetwo_os.kernel import get_os, boot_os
        
        print("🔧 Initializing CircuitPython OS...")
        
        # Get OS instance
        kernel = get_os()
        
        # Start the OS in a separate thread-like manner
        print("🚀 Booting OS...")
        
        # Manual boot process for demo
        kernel._init_core_systems()
        kernel._load_drivers()
        kernel._mount_filesystems()
        kernel._start_services()
        kernel._load_applications()
        
        print("✅ OS Boot Complete!")
        print(f"📊 Memory: {gc.mem_free()//1024}KB free")
        print(f"⚙️ Services: {len(kernel.services)}")
        print(f"🔌 Drivers: {len(kernel.drivers)}")
        
        # Auto-launch some apps for demo
        print("\n🚀 Auto-launching demo applications...")
        
        # Launch system monitor
        try:
            from stagetwo_os.apps.system_monitor import create_app
            sys_monitor = create_app(kernel)
            if sys_monitor.start():
                kernel.scheduler.add_process(sys_monitor)
                print("✅ System Monitor launched")
        except Exception as e:
            print(f"⚠️ System Monitor failed: {e}")
        
        # Launch app launcher
        try:
            from stagetwo_os.apps.app_launcher import create_app
            app_launcher = create_app(kernel)
            if app_launcher.start():
                kernel.scheduler.add_process(app_launcher)
                print("✅ App Launcher launched")
        except Exception as e:
            print(f"⚠️ App Launcher failed: {e}")
        
        # Setup input handling
        try:
            from stagetwo_os.drivers.input_driver import get_input_driver
            input_driver = get_input_driver()
            
            # Register button callbacks for navigation
            def on_button_press(button_name, event_type):
                print(f"🔘 Button {button_name} {event_type}")
                
                # Simple navigation example
                if button_name == 'main' and event_type == 'click':
                    print("🎯 Main button clicked - could switch apps")
            
            for button_name in input_driver.get_available_buttons():
                input_driver.register_callback(button_name, 'click', on_button_press)
            
            print("✅ Input handling configured")
            
        except Exception as e:
            print(f"⚠️ Input setup failed: {e}")
        
        # Start main OS loop
        print("\n🔄 Starting OS main loop...")
        print("🔘 Press buttons to interact")
        print("🛑 Press Ctrl+C to stop")
        
        kernel.running = True
        loop_count = 0
        
        while kernel.running:
            try:
                # Run scheduler
                kernel.scheduler.tick()
                
                # Process events
                kernel.event_system.process_events()
                
                # Handle input
                if 'input_driver' in locals():
                    input_driver.poll_inputs()
                
                # Memory management
                kernel.memory_manager.tick()
                
                # Periodic status update
                loop_count += 1
                if loop_count % 1000 == 0:  # Every ~10 seconds
                    print(f"💓 OS heartbeat - {gc.mem_free()//1024}KB free")
                
                # Small delay for cooperative multitasking
                time.sleep(0.01)
                
            except KeyboardInterrupt:
                print("\n🛑 Shutdown requested")
                break
            except Exception as e:
                print(f"⚠️ OS loop error: {e}")
                time.sleep(1)  # Prevent rapid error loops
        
        # Shutdown
        print("🛑 Shutting down StageTwo OS...")
        kernel.shutdown()
        print("✅ OS Demo completed")
        
    except ImportError as e:
        print(f"❌ OS modules not found: {e}")
        print("💡 Make sure all OS files are in stagetwo_os/ directory")
        
    except Exception as e:
        print(f"❌ Demo error: {e}")
        import traceback
        traceback.print_exc()

# Run the demo
if __name__ == "__main__":
    demo_stagetwo_os()
